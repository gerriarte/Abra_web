import React, { useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Section } from './components/Section';
import { Stats } from './components/Stats';
import { ImageGrid } from './components/ImageGrid';
import { TableOfContents } from './components/TableOfContents';
import { ProjectDetails } from './components/ProjectDetails';
import { DIFFERENT_COFFEE_CASE } from './constants';

export default function App() {
  
  // Simple smooth scroll behavior for anchor links
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      if (anchor && anchor.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const id = anchor.getAttribute('href')?.substring(1);
        const element = document.getElementById(id || '');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }
    };
    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="min-h-screen w-full overflow-x-hidden bg-white">
      <Navbar />
      <TableOfContents />
      
      <main>
        <Hero 
          title={DIFFERENT_COFFEE_CASE.title}
          subtitle={DIFFERENT_COFFEE_CASE.client}
          backgroundImage="https://picsum.photos/1920/1080?grayscale"
          category="Estrategia de Pauta Digital"
        />

        {/* Marca / Intro */}
        <Section 
          id="brand"
          category="Marca"
          title="Different Coffee"
          description={DIFFERENT_COFFEE_CASE.brandDescription}
          align="left"
        />

        {/* Situación */}
        <Section 
          id="situation"
          category="Situación"
          title="El Desafío del Mercado"
          description={DIFFERENT_COFFEE_CASE.situation}
          image="https://picsum.photos/800/1000?random=1"
          align="right"
          hasDivider
        />

        {/* Tarea */}
        <Section 
          id="task"
          category="Tarea"
          title="Objetivos Claros"
          description={DIFFERENT_COFFEE_CASE.task}
          align="left"
          theme="dark"
        />

        {/* Acción */}
        <Section 
          id="action"
          category="Acción"
          title="Ejecución Estratégica"
          description={DIFFERENT_COFFEE_CASE.action}
          video="https://www.youtube.com/embed/M7lc1UVf-VE?rel=0&controls=1"
          align="right"
        />

        <ProjectDetails 
          details={DIFFERENT_COFFEE_CASE.projectDetails} 
          clientName={DIFFERENT_COFFEE_CASE.client} 
        />

        <ImageGrid />

        {/* Resultado */}
        <Stats stats={DIFFERENT_COFFEE_CASE.results} />
        
      </main>
    </div>
  );
}