import { CaseStudy } from './types';

export const DIFFERENT_COFFEE_CASE: CaseStudy = {
  id: 'different-coffee-001',
  client: 'Different Coffee',
  title: 'Redefiniendo la Experiencia del Café Especialidad',
  brandDescription: 'Different Coffee es una tostaduría boutique que busca democratizar el acceso al café de especialidad. Con un enfoque en la trazabilidad y el comercio justo, su identidad visual y verbal refleja sofisticación, pero con un tono accesible y humano. No venden solo granos; venden rituales matutinos.',
  situation: 'A pesar de tener un producto superior y una marca visualmente potente, Different Coffee enfrentaba un estancamiento en su canal e-commerce. El costo por adquisición (CPA) en Meta Ads había aumentado un 40% debido a la saturación de competidores genéricos, y la retención de clientes (LTV) era baja.',
  task: 'Nuestra misión fue clara: Reestructurar el ecosistema de pauta digital para optimizar el CPA por debajo de $15 USD y aumentar la tasa de recompra en un 20% durante el Q4, aprovechando la temporada alta para posicionar la marca como líder en regalos corporativos y consumo hogareño premium.',
  action: 'Implementamos una estrategia "Full-Funnel". En la etapa de descubrimiento, utilizamos videos de alto impacto (Reels/TikTok) centrados en el ASMR de la preparación del café para generar deseo sensorial. En consideración, activamos campañas de Google Search y Shopping para capturar intención de compra de "café de especialidad". Finalmente, para retención, diseñamos flujos de Email Marketing automatizados post-compra y campañas de Remarketing dinámico con ofertas exclusivas para suscripciones mensuales.',
  results: [
    { label: 'Retorno de Inversión (ROAS)', value: '4.5', suffix: 'x' },
    { label: 'Reducción de CPA', value: '32', suffix: '%' },
    { label: 'Tasa de Conversión', value: '2.8', suffix: '%' },
    { label: 'Nuevos Suscriptores', value: '+150', suffix: '' },
  ],
  projectDetails: {
    logo: 'https://placehold.co/400x150/171717/ffffff/png?text=Different+Coffee&font=playfair',
    year: '2023',
    duration: '4 Meses (Sept - Dic)',
    services: ['Estrategia Digital', 'Paid Media', 'Content Creation', 'Email Automation'],
    team: [
      { role: 'Director Creativo', name: 'Ana Silva' },
      { role: 'Growth Manager', name: 'Carlos Ruiz' },
      { role: 'Copywriter', name: 'Elena Martínez' }
    ]
  }
};