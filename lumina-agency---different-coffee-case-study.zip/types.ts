export interface Metric {
  label: string;
  value: string;
  prefix?: string;
  suffix?: string;
}

export interface TeamMember {
  role: string;
  name: string;
}

export interface ProjectDetailsType {
  logo?: string;
  year: string;
  duration: string;
  services: string[];
  team: TeamMember[];
}

export interface CaseStudy {
  id: string;
  client: string;
  title: string;
  brandDescription: string;
  situation: string;
  task: string;
  action: string;
  results: Metric[];
  projectDetails: ProjectDetailsType;
}