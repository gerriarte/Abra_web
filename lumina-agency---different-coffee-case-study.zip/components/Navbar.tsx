import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-white/90 backdrop-blur-md py-4 shadow-sm' : 'bg-transparent py-8'}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <a href="#" className={`text-2xl font-serif font-bold tracking-tighter mix-blend-difference ${isScrolled ? 'text-neutral-900' : 'text-white'}`}>
          LUMINA.
        </a>

        <div className="hidden md:flex space-x-12 text-sm font-medium tracking-widest uppercase">
          <a href="#brand" className={`hover:opacity-50 transition-opacity ${isScrolled ? 'text-neutral-900' : 'text-white'}`}>Marca</a>
          <a href="#situation" className={`hover:opacity-50 transition-opacity ${isScrolled ? 'text-neutral-900' : 'text-white'}`}>Situación</a>
          <a href="#action" className={`hover:opacity-50 transition-opacity ${isScrolled ? 'text-neutral-900' : 'text-white'}`}>Acción</a>
          <a href="#results" className={`hover:opacity-50 transition-opacity ${isScrolled ? 'text-neutral-900' : 'text-white'}`}>Resultados</a>
        </div>

        <button 
          className="md:hidden z-50 text-neutral-900"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
           {isMenuOpen ? <X className={isScrolled ? 'text-neutral-900' : 'text-white'} /> : <Menu className={isScrolled ? 'text-neutral-900' : 'text-white'} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-white z-40 flex flex-col items-center justify-center space-y-8">
           <a href="#brand" onClick={() => setIsMenuOpen(false)} className="text-2xl font-serif text-neutral-900">Marca</a>
           <a href="#situation" onClick={() => setIsMenuOpen(false)} className="text-2xl font-serif text-neutral-900">Situación</a>
           <a href="#action" onClick={() => setIsMenuOpen(false)} className="text-2xl font-serif text-neutral-900">Acción</a>
           <a href="#results" onClick={() => setIsMenuOpen(false)} className="text-2xl font-serif text-neutral-900">Resultados</a>
        </div>
      )}
    </nav>
  );
};