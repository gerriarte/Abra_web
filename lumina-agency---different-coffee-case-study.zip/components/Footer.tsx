import React from 'react';
import { ArrowUpRight } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white text-neutral-900 py-20 px-6 border-t border-neutral-100">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-12">
        <div>
          <h2 className="text-3xl font-serif font-bold tracking-tighter mb-2">LUMINA.</h2>
          <p className="text-neutral-500 text-sm">Digital Agency & Branding.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-8 md:gap-16">
          <div className="flex flex-col gap-4">
            <h4 className="uppercase text-xs font-bold tracking-widest text-neutral-400">Contacto</h4>
            <a href="#" className="text-lg hover:text-neutral-600 transition-colors">hello@lumina.agency</a>
            <a href="#" className="text-lg hover:text-neutral-600 transition-colors">+1 (555) 000-0000</a>
          </div>
          
          <div className="flex flex-col gap-4">
             <h4 className="uppercase text-xs font-bold tracking-widest text-neutral-400">Social</h4>
             <a href="#" className="text-lg hover:text-neutral-600 transition-colors flex items-center gap-2">Instagram <ArrowUpRight size={16} /></a>
             <a href="#" className="text-lg hover:text-neutral-600 transition-colors flex items-center gap-2">LinkedIn <ArrowUpRight size={16} /></a>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-neutral-100 flex flex-col md:flex-row justify-between items-center text-xs text-neutral-400">
        <p>© {new Date().getFullYear()} Lumina Agency. All rights reserved.</p>
        <div className="flex gap-6 mt-4 md:mt-0">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};